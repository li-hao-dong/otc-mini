# otc-mini　项目

# 技术栈
- Vue3.0
- Vite
- TypeScript
- Pinia
- Mock js
