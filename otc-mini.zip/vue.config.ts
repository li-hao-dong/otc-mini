export = {
    transpileDependencies:['@dcloudio/uni-ui']
}
