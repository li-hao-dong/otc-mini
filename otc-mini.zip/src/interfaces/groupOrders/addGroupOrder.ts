export interface AddGroupOrder {
    "groupOrderNo": string;
    "orderNo": string;
    "groupStatus": string;
    "currentSize": number;
    "targetSize": number;
    [property: string]: any;
}
