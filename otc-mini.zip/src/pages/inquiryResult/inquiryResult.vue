<template>
  <view class="container resultPage">
    <view class="card">
      <view class="row rowTop">
        <view class="asset">
          <text class="assetName">{{ assetName }}</text>
          <text class="assetCode">{{ assetCode }}</text>
        </view>
        <view class="para">
          <text class="labelText">股价：</text>
          <text class="valueText" :class="calcClassName(priceChange)">{{ currentPrice }}</text>
        </view>
        <view class="para">
          <text class="labelText" >涨幅：</text>
          <text class="valueText" :class="calcClassName(priceChange)">{{ priceChange }}</text>
        </view>
      </view>

      <view class="row rowMid">
<!--        <view class="para"><text class="labelBold">询价人：{{useStore().user.name ? useStore().user.name : null }}</text></view>-->
        <view class="para"><text class="labelBolder">询价规模：{{ nominalAmount }} 万</text></view>
      </view>


      <view style=" margin-top: 10px; " v-if="terms && terms.length">
        <view :class="`grid_col ${calcColNum(terms?.length)}`" ref="gridCol" :style="`width: 100%; color: #777777; display: grid; font-size: 12px; padding-bottom: 10px; border-bottom: 1px solid #eaeaea;`">
          <view >结构</view>
          <view v-for="(term, index) in terms" :key="index">{{ term }}</view>
          <view >报价方</view>
        </view>
        <view :class="`grid_col ${calcColNum(terms?.length)}`" :style="`width: 100%; display: inline-grid; align-items: center; padding: 10px 0; line-height: 20px; border-bottom: 1px solid #eaeaea;`"
              v-for="(item, index) in results" :key="index">
          <view>{{ item.structureName }}</view>
          <view v-for="(term, i) in terms" :key="i">
            <view style="line-height: 26px;" v-for="(quote, x) in Object.values(item.quotes)" :key="x" :class="quote[term] && quote[term][0].isRecommended?'rise_color':''" @click="placeAnOrder(quote[term][0], term, item)">
              {{ `${quote[term] ? quote[term][0].price+'%' : '-'}` }}<uni-icons v-if="quote[term]" type="right" size="15"></uni-icons>
            </view>
          </view>
          <view>
            <view style="line-height: 26px;" v-for="(quote, x) in Object.keys(item.quotes)" :key="x">{{ quote }}</view>
          </view>
        </view>
      </view>

<!--      <uni-table ref="table" border stripe emptyText="暂无更多数据">-->
<!--        <uni-tr>-->
<!--          <uni-th align="center">结构</uni-th>-->
<!--          <uni-th align="center" v-for="(term, index) in terms" :key="index">{{ term }}</uni-th>-->
<!--          <uni-th align="center">报价方</uni-th>-->
<!--        </uni-tr>-->
<!--        <uni-tr >-->
<!--          <uni-td>{{ item.structureName }}</uni-td>-->
<!--          <uni-td v-for="(term, i) in terms" :key="i">{{ item.terms[term].price }}%</uni-td>-->
<!--          <uni-td>{{ item.sourceCode }}</uni-td>-->
<!--        </uni-tr>-->
<!--      </uni-table>-->

      <view class="hint_text actions">
        请点击报价查看详情并下单。当前报价为0时，代表暂未查询到可成交的实时报价。你仍然可以下单，由通道侧人工或离线系统为您寻找可成交报价。
      </view>

      <view class="row">
<!--        <view class="btn fixed" role="button" tabindex="0"><text class="btnText">客服</text></view>-->
        <view class="btn grow" role="button" tabindex="0" @click="toInquiry"><text class="btnText">重新询价</text></view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import {getCurrentInstance, onMounted, ref, watch} from "vue";
import {failToast, hideLoading, loadingToast} from "@/utils/toast/toast";
import {inquiryQuote} from "@/api";
import type {InquiryResp, Quote, QuoteResult} from "@/interfaces/inquiry/inquiryQuote";
import {onLoad, onReady, onShow} from "@dcloudio/uni-app";
import {useStore} from "../../stores";
import {calcClassName} from "@/utils";

const inquiryId = ref<string | undefined>();
const assetName = ref<string | undefined>();
const assetCode = ref<string | undefined>();
const currentPrice = ref<number | undefined>();
const nominalAmount = ref<number | undefined>();
const optionType = ref<string | undefined>();
const priceChange = ref<string | undefined>();
const terms = ref<string[] | undefined>();
const results = ref<QuoteResult[] | undefined>([]);
const gridCol = ref<string>("");

onLoad(() => {
  getInquiryResults();
})

const calcColNum = (num: number | undefined) => {
  if(!num || num <=0) return "";
  return `grid_col_${num}`;
}

const getInquiryResults = () => {
  // Placeholder for fetching inquiry results

  const payload = uni.getStorageSync('InquiryQuoteReqPayload')
  if(Object.keys(payload).length === 0){
    // console.log("没有询价请求参数")
    return;
  }

  loadingToast("询价中");
  inquiryQuote(payload).then((res: InquiryResp) =>{
    // console.log("inquiryQuote res1111,", res.data)
    inquiryId.value = res.data.inquiryId;
    assetName.value = res.data.underlying;
    assetCode.value = res.data.underlyingCode;
    currentPrice.value = res.data.currentPrice;
    priceChange.value = res.data.priceChange;
    nominalAmount.value = res.data.nominalAmount;
    optionType.value = res.data.optionType;
    // interface QuoteItem {
    //   structure: string;
    //   structureName: string;
    //   term: string;
    //   termName: string;
    //   quotes: {
    //     price: string;
    //     sourceCode: string;
    //   }[];
    // }
    //

    formatInquiryStruct(res.data.results)
    uni.hideLoading()
  }).catch((err) => {
    // failToast("询价失败，请稍后重试");
    // uni.showToast({title: "未匹配到标的", duration: 2000, icon: "error"})
    // console.log("inquiryQuote error,", err)
    uni.showModal({
      title: '询价失败',
      content: err?.message,
      showCancel: false,
      success: () => {
        uni.hideLoading()
        uni.redirectTo({
          url: '/pages/inquiry/inquiry'
        });
      }
    })
  })

};

const formatInquiryStruct = (quoteResult:QuoteResult[]) =>　{
  // console.log("quoteResult", quoteResult)
  const filterData: any = {};
  quoteResult.map((item:QuoteResult) => {
    // console.log("item", item)
    // 处理结构与周期
    if(!filterData[item.structure!]){
      filterData[item.structure!] = {
        structure: item.structure,
        structureName: item.structureName,
        terms: {
          [item.termName!]: item.term,
        },
        quotes: {}
      };
    } else {
      filterData[item.structure!] = {
        ...filterData[item.structure!],
        terms: {
          ...filterData[item.structure!].terms,
          [item.termName!]: item.term
        },
        quotes: {
          ...filterData[item.structure!].quotes
        }
      };
    }
    // 处理 供应商 的周期数据
    item.quotes?.map((quote:Quote) => {
      filterData[item.structure!] = {
        ...filterData[item.structure!],
        quotes: {
          ...filterData[item.structure!].quotes,
          [quote.sourceCode!]: {
            ...filterData[item.structure!].quotes[quote.sourceCode!],
            [item.termName!]: filterData[item.structure!].quotes[quote.sourceCode!] && filterData[item.structure!].quotes[quote.sourceCode!][item.termName!]?.length > 0 ? filterData[item.structure!].quotes[quote.sourceCode!][item.termName!].push(quote) :[quote]
            // [item.termName!]: quote
          }
        }
      };
      // console.log(item.structure, "|", quote.sourceCode, "|", item.termName, "|", filterData[item.structure!].quotes[quote.sourceCode!])

    })
  });


  Object.keys(filterData[Object.keys(filterData)[0]].terms).map((termKey) => {
    filterData[Object.keys(filterData)[0]].terms[termKey] = {
      term: termKey,
      termName: filterData[Object.keys(filterData)[0]].terms[termKey],
      days: Number(filterData[Object.keys(filterData)[0]].terms[termKey].replace("W", "")) * 7 || Number(filterData[Object.keys(filterData)[0]].terms[termKey].replace("M", "")) * 30 || 0
    }
  })

  terms.value = Object.values(filterData[Object.keys(filterData)[0]].terms).sort((a,b) => a.days - b.days).map(termObj => termObj.term);
  results.value = Object.values(filterData)
  // console.log("filterData,", filterData)
  // console.log("terms,", terms.value)
  gridCol.value = `20% repeat(${terms.value?.length}, 1fr) 20%`;
}

const toInquiry = () => {
  uni.redirectTo({
    url: '/pages/inquiry/inquiry'
  });
}

const placeAnOrder = (quote: any, term: string, result: any) => {
  // console.log("placeAnOrder", quote)
  // console.log("assetName:", assetName.value)
  // console.log("assetCode:", assetCode.value)
  // console.log("priceChange:", priceChange.value)
  // console.log("currentPrice:", currentPrice.value)
  // console.log("nominalAmount:", nominalAmount.value)
  // console.log("quote:", quote)
  // console.log("result:", result)
  const payload = {
    inquiryId: inquiryId.value,
    assetName: assetName.value,
    assetCode: assetCode.value,
    priceChange: priceChange.value,
    currentPrice: currentPrice.value,
    nominalAmount: nominalAmount.value,
    quote: quote,
    term: term,
    structure: result.structure,
    structureName: result.structureName,
    optionType: optionType.value,
  };
  uni.setStorageSync('OrderPayload', payload)

  uni.navigateTo({url: '/pages/orderPlacement/orderPlacement'});
}

</script>

<style>
.resultPage { background-color: #f5f5f5; }

.card {
  width: 100%;
  margin: 0 auto;
  background-color: #ffffff;
  display: flex;
  flex-direction: column;
  gap: 1px;
  padding: 10px 2.5%;
  box-sizing: border-box;
}

.row { display: flex; align-items: center; }

.rowTop {
  justify-content: space-between;
  /* gap: 67.6px; */
  /* padding: 10px 0 11px; */
  border-bottom: 1px solid #eeeeee;
}

.rowMid {
  justify-content: space-between;
  padding: 9px 0 10px;
  border-bottom: 1px solid #eeeeee;
}

.para { display: flex; align-items: center; gap: 4px; }

.grid_col_1{
  grid-template-columns: 20% repeat(1, 1fr) 20%;
}

.grid_col_2{
  grid-template-columns: 20% repeat(2, 1fr) 20%;
}

.grid_col_3{
  grid-template-columns: 20% repeat(3, 1fr) 20%;
}

.asset { display: flex; flex-direction: column; padding: 0 0 10px 0; }
.assetName { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif; font-weight: 700; font-size: 15.6px; line-height: 1.21em; color: #000000; }
.assetCode { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif; font-weight: 400; font-size: 16px; line-height: 1.21em; color: #999999; padding-top: 2px;}

.labelText {
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 1.21em;
  color: #000000;
}

.valueText {
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  font-weight: 700;
  font-size: 15.6px;
  line-height: 1.21em;
}

.labelBold {
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  font-weight: 700;
  font-size: 16px;
  line-height: 1.21em;
  color: #000000;
}

.labelBolder {
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  line-height: 1.21em;
  color: #000000;
}

.table { width: 100%; align-self: stretch; }
.tableHeader { display: flex; justify-content: center; width: 100%; }

.th {
  background-color: #f8f8f8;
  border: 1px solid #eeeeee;
  padding: 9.5px 9px 11.5px;
  box-sizing: border-box;
  width: 100%;
  font-size: 14px;
}

.tableBody { width: 100%; }
.tr { width: 100%; display: flex; justify-content: space-between; }
.td { padding: 10px 9px; border-bottom: 1px solid #eeeeee; box-sizing: border-box; font-size: 14px; text-align: center; border: 1px solid red;}
.bold { font-weight: 700; }
.red { color: #e63946; }

.actions { justify-content: space-between; padding: 29px 0 10px; }

.btn {
  background-color: #e63946;
  border-radius: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 11px 20px 12px;
}
.fixed { width: 120px; }
.grow { flex: 1; }
.btnText {
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 1.21em;
  color: #ffffff;
}

.hint_text{
  font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, sans-serif;
  font-weight: 400;
  font-size: 13px;
  line-height: 1.21em;
  color: #999999;
}
</style>
